<template>
    <div>
        <div class="info">
            <h2>{{ article.title }}</h2>
            <h3 style="margin: 20px 0px">{{ article.digest }}</h3>
        </div>
        <el-divider content-position="left">正文</el-divider>
        <div class="content">
            <v-md-preview :text="article.content"></v-md-preview>
        </div>
        <el-divider content-position="left">评论</el-divider>
        <div class="demo-collapse">
            <el-collapse>
                <el-collapse-item :name="index" v-for="(cp, index) in comment.data" :key="cp.id">
                    <template #title>
                        <div class="comment">
                            <el-avatar size="small" :src="cp.user_avatar"></el-avatar>
                            <p class="username">{{ cp.user_name }}：</p>
                            <p class="username">{{ cp.content }}</p>
                            <p class="digest">{{ cp.create_time }}</p>
                        </div>
                    </template>
                    <div v-for="cs in cp.sonComment" :key="cs.id">
                        <div class="comment son_comment">
                            <el-avatar size="small" :src="cs.user_avatar"></el-avatar>
                            <p class="username">{{ cs.user_name }} 回复 {{ cs.reply_username }}：</p>
                            <p class="username">{{ cs.content }}</p>
                            <p class="digest">{{ cs.create_time }}</p>
                        </div>
                    </div>
                </el-collapse-item>
            </el-collapse>
        </div>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { getArticleDetail } from '@/api/community'
import { useRoute } from "vue-router"

let article = ref({
})
const router = useRoute()
getArticleDetail(router.params.id).then((data) => {
    article.value = data
})

let comment = reactive({
    data: [
        {
            "id": 1,
            "sonComment": [
                {
                    "id": 3,
                    "user_name": "俊果果",
                    "user_avatar": null,
                    "reply_username": "墨染",
                    "content": "我也这么觉得",
                    "level": 2,
                    "parent_comment": 1,
                    "reply_comment": 1,
                    "create_time": "2021-11-29T21:13:06.988467",
                    "article": 3,
                    "user": 3
                }
            ],
            "user_name": "墨染",
            "user_avatar": null,
            "content": "写的非常好",
            "level": 1,
            "parent_comment": null,
            "reply_comment": null,
            "create_time": "2021-11-29T21:11:53.824367",
            "article": 3,
            "user": 2
        }
    ]
})
</script>

<style lang="less" scoped>
.comment {
    display: flex;
    align-items: center;
}

.comment .username {
    margin: 0px 10px;
}

.son_comment {
    margin: 5px 20px;
    padding-left: 5px;
    border-left: 1px solid lightgray;
}
</style>