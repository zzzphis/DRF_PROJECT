<template>
    <div>
        <el-form :model="form" label-width="auto" :rules="rules" ref="ruleFormRef" :inline="true">
            <el-form-item label="标题" prop="title">
                <el-input v-model="form.title"></el-input>
            </el-form-item>
            <el-form-item label="摘要" prop="digest">
                <el-input v-model="form.digest"></el-input>
            </el-form-item>
            <el-form-item label="标签" prop="label">
                <el-select v-model="form.label" placeholder="请选择文章标签">
                    <el-option :label="i.name" :value="i.id" v-for="i in label"></el-option>
                </el-select>
            </el-form-item>
            <el-form-item>
                <el-button type="primary" @click="submitForm(ruleFormRef, 0)">保存草稿</el-button>
                <el-button type="primary" @click="submitForm(ruleFormRef, 1)">立即发布</el-button>
            </el-form-item>
        </el-form>
        <v-md-editor v-model="form.content" height="400px"></v-md-editor>
    </div>
</template>

<script setup>
import { ref, reactive } from 'vue'
import { getLabel, createArticle } from '@/api/community'
import { ElMessage } from 'element-plus'

const label = ref()
getLabel().then((data) => {
    label.value = data
})

const ruleFormRef = ref()

const form = reactive({
    title: '',
    digest: '',
    content: '',
    label: '',
    status: 0
})

const rules = reactive({
    title: [
        {
            required: true,
            message: '请输入文章标题',
            trigger: 'blur',
        },
        {
            min: 1,
            max: 100,
            message: '长度为1-100',
            trigger: 'blur',
        },
    ],
    label: [
        {
            required: true,
            message: '请选择标签',
            trigger: 'change',
        },
    ],
    digest: [
        {
            required: true,
            message: '请输入文章摘要',
            trigger: 'blur',
        },
        {
            min: 1,
            max: 100,
            message: '长度为1-300',
            trigger: 'blur',
        },
    ]
})

const submitForm = async (formEl, status) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            form.status = status
            createArticle(form).then((data) => {
                ElMessage({
                    message: '操作成功',
                    type: 'success',
                })
            }).catch((error) => {
                let data = error.response.data
                for (let key in data) {
                    console.log(key);
                    ElMessage({
                        message: data[key][0],
                        type: 'warning',
                    })
                }
            })
        } else {
            console.log('error submit!', fields)
        }
    })
}
</script>

<style lang="less" scoped></style>