<template>
    <div>
        <div class="func">
            <router-link to="/article/publish">
                <el-button type="primary">
                    <el-icon>
                        <Edit />
                    </el-icon>去发表
                </el-button>
            </router-link>
        </div>
        <ul v-infinite-scroll="load" class="infinite-list" style="overflow: auto" :infinite-scroll-disabled="disabled">
            <li v-for="(e, i) in articles" :key="i" class="infinite-list-item">
                <router-link :to="'/article/' + e.id">
                    <el-card class="box-card">
                        <template #header>
                            <div class="card-header">
                                <h3>{{ e.title }}</h3>
                                <p style="color: gray;font-size: 14px;">{{ e.create_time }}</p>
                            </div>
                        </template>
                        <div class="article_info">
                            <div class="user_info">
                                <el-avatar size="small" :src="'/file' + e.user_avatar"></el-avatar>
                                <p class="username">{{ e.user_name }}</p>
                                <p class="digest">{{ e.digest }}</p>
                            </div>
                            <div>
                                <el-icon>
                                    <pointer />
                                </el-icon>
                                <span class="digest">浏览量：{{ e.page_view }}</span>
                            </div>
                        </div>
                    </el-card>
                </router-link>
            </li>
        </ul>
        <p v-if="loading">Loading...</p>
        <el-empty :image-size="20" v-if="noMore" description="暂无更多内容"></el-empty>
    </div>
</template>

<script setup>
import { computed, ref } from 'vue'
import { getArticle } from '@/api/community'
import { Edit } from '@element-plus/icons-vue'

const articles = ref()
const count = ref(0)
const limit = ref(3)
const offset = ref(3)

const loading = ref(false)
const noMore = ref(false)
const disabled = computed(() => loading.value || noMore.value)

function getArticles() {
    loading.value = true
    noMore.value = false
    offset.value = 0
    getArticle().then((data) => {
        articles.value = data.results
        count.value = data.count
        console.log(offset.value + limit.value, count.value);
        if (offset.value + limit.value > count.value) {
            noMore.value = true
        }
        offset.value = limit.value + offset.value
        loading.value = false
    })
}
getArticles()

const load = () => {
    loading.value = true
    getArticle({
        limit: limit.value,
        offset: offset.value
    }).then((data) => {
        articles.value = articles.value.concat(data.results)
        offset.value = limit.value + offset.value
        loading.value = false
        if (offset.value + limit.value > count.value) {
            noMore.value = true
        }
    })
}
</script>

<style lang="less" scoped>
.article_digest {
    margin: 20px 0px;
    font-size: 14px;
    color: gray;
}

.func {
    display: flex;
    justify-content: flex-end;
    margin-bottom: 20px;
}

.card-header {
    display: flex;
    justify-content: space-between;
}

.article_info {
    display: flex;
    justify-content: space-between;
}

.article_info .user_info {
    display: flex;
    justify-content: flex-start;
    align-items: center;
}

.article_info .user_info .username {
    margin: 0px 20px;
}

.digest {
    color: gray;
    font-size: 14px;
    width: 1000px;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
}

.box-card {
    margin: 20px 0px;
}
</style>