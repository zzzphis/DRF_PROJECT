<template>
    <el-result v-if="trade_id" icon="success" title="支付成功" :sub-title="`您的订单：${order_id}支付成功，支付交易号：${trade_id}`">
        <template #extra>
            <router-link to="/user/order">
                <el-button type="primary" size="medium">Back</el-button>
            </router-link>
        </template>
    </el-result>
</template>

<script setup>
import { ref } from 'vue'
import { useRouter } from 'vue-router'
import { changeOrder } from '@/api/shopping'

const router = useRouter()

const order_id = ref()
const trade_id = ref()

changeOrder(document.location.search).then(
    data => {
        console.log('请求成功', data)
        order_id.value = data.order_id
        trade_id.value = data.trade_id
    },
    error => {
        console.log('请求失败', error.message)
    }
)
</script>

<style lang="less" scoped></style>