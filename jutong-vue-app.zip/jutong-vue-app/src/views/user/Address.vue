<template>
    <div>
        <div class="func">
            <el-button type="primary" @click="dialogFormVisible = true">+ 添加收货地址</el-button>
        </div>
        <el-card class="box-card" v-for="res in address" :key="res.id">
            <template #header>
                <div class="card-header">
                    <h4>{{ res.name }}</h4>

                    <div>
                        <el-popconfirm title="确定要删除这个地址吗?" @confirm="deleteAddress(res.id)">
                            <template #reference>
                                <el-button type="danger" :icon="Delete" circle />
                            </template>
                        </el-popconfirm>
                    </div>
                </div>
            </template>
            <div class="text item address_info">
                <p>
                    <span class="lab">收货人：</span>
                    {{ res.receiver }}
                </p>
                <p>
                    <span class="lab">所在地区：</span>
                    {{ res.province_name }}-{{ res.city_name }}-{{ res.district_name }}
                </p>
                <p>
                    <span class="lab">详细地址：</span>
                    {{ res.place }}
                </p>
                <p>
                    <span class="lab">手机：</span>
                    {{ res.mobile }}
                </p>
            </div>
        </el-card>
    </div>
    <el-dialog v-model="dialogFormVisible" title="添加收货地址">
        <el-form ref="ruleFormRef" :model="ruleForm" :rules="rules" label-width="120px" class="demo-ruleForm"
            status-icon>
            <el-form-item label="地址名" prop="name">
                <el-input v-model="ruleForm.name" />
            </el-form-item>
            <el-form-item label="收货人" prop="receiver">
                <el-input v-model="ruleForm.receiver" />
            </el-form-item>
            <el-form-item label="联系方式" prop="mobile">
                <el-input v-model="ruleForm.mobile" />
            </el-form-item>
            <el-form-item label="省市区" prop="area">
                <el-cascader :props="props" v-model="ruleForm.area" />
            </el-form-item>
            <el-form-item label="详情地址" prop="place">
                <el-input v-model="ruleForm.place" />
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取消</el-button>
                <el-button type="primary" @click="changePassword(ruleFormRef)">
                    提交
                </el-button>
            </span>
        </template>
    </el-dialog>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { getArea, getAreaDetail, addAddress, getAddress, delAddress } from '@/api/user'
import {
    Delete,
} from '@element-plus/icons-vue'

const dialogFormVisible = ref(false)
const ruleFormRef = ref()
const ruleForm = reactive({
})
const rules = reactive({
    name: [
        { required: true, message: '请输入地址名', trigger: 'blur' },
    ],
    receiver: [
        { required: true, message: '请输入收货人', trigger: 'blur' },
    ],
    place: [
        { required: true, message: '请输入详情地址', trigger: 'blur' },
    ],
    mobile: [
        { required: true, message: '请输入手机号', trigger: 'blur' },
    ],
    area: [
        { required: true, message: '请选择省市区', trigger: 'blur' },
    ]
})

const props = {
    lazy: true,
    lazyLoad(node, resolve) {
        const { level } = node
        if (level == 0) {
            let nodes = []
            getArea().then((data) => {
                data.forEach(element => {
                    nodes.push({
                        value: element.id,
                        label: element.name,
                        leaf: level >= 2
                    })
                });
                resolve(nodes)
            })
        } else {
            let nodes = []
            getAreaDetail(node.data.value).then((data) => {
                console.log(data);
                data.area_set.forEach(element => {
                    nodes.push({
                        value: element.id,
                        label: element.name,
                        leaf: level >= 2
                    })
                });
                resolve(nodes)
            })
        }
    },
}

const changePassword = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            console.log(ruleForm);
            ruleForm.province = ruleForm.area[0]
            ruleForm.city = ruleForm.area[1]
            ruleForm.district = ruleForm.area[2]
            addAddress(ruleForm).then((data) => {
                ElMessage({
                    message: '添加成功',
                    type: 'success',
                })
                dialogFormVisible.value = false
                address.value.unshift(data)
            })
        } else {
            console.log('error submit!', fields)
        }
    })
}

const deleteAddress = (id) => {
    delAddress(id).then((data) => {
        ElMessage({
            message: '删除成功',
            type: 'success',
        })
    })
    address.value = address.value.filter((item) => item.id!= id)
}

const address = ref([])
getAddress().then((data) => {
    address.value = data
})
</script>

<style lang="less" scoped>
.func {
    display: flex;
    justify-content: right;
    margin-bottom: 20px;
}

.address_info p {
    margin: 10px 0px;
    font-size: 14px;
}

.address_info p .lab {
    display: inline-block;
    width: 120px;
    text-align: right;
    color: gray;
}

.box-card {
    margin-bottom: 20px;

    .card-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
}
</style>