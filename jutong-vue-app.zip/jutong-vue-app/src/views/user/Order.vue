<template>
    <el-header>
        <div class="info">
            <div>
                <h3>Jutong</h3>
                <h4>Jutong系统</h4>
            </div>
        </div>
        <el-divider direction="vertical"></el-divider>
        <h4>订单</h4>
    </el-header>
    <el-table :data="orders" style="width: 100%" stripe>
        <el-table-column property="order_id" label="订单编号" />
        <el-table-column property="total_count" label="商品总数" width="100" />
        <el-table-column property="total_amount" label="订单总金额" width="150" />
        <el-table-column label="订单状态" width="150">
            <template #default="scope">
                <el-tag :type="TAG[(scope.row.status - 1) % TAG.length]">{{ STATUS_CHOICES[scope.row.status - 1] }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column label="支付方式" width="150">
            <template #default="scope">
                <el-button type="danger" v-if="scope.row.status == 1" @click="payment(scope.row.order_id)">
                    去支付</el-button>
                <el-tag v-else :type="TAG[scope.row.pay_method - 1]">{{ PAY_METHOD_CHOICES[scope.row.pay_method - 1] }}
                </el-tag>
            </template>
        </el-table-column>
        <el-table-column property="address" label="收货地址" />
        <!-- <el-table-column label="收货地址">
            <template
                #default="scope"
            >{{ scope.row.addressDetail.province_name }} {{ scope.row.addressDetail.city_name }} {{ scope.row.addressDetail.district_name }} {{ scope.row.addressDetail.place }}</template>
        </el-table-column> -->
        <el-table-column label="创建时间" show-overflow-tooltip>
            <template #default="scope">{{ scope.row.create_time.replace('T', ' ').split('.')[0] }}</template>
        </el-table-column>
    </el-table>
</template>

<script setup>
import { ref } from 'vue'
import { getOrder, goPay } from '@/api/shopping'
import { ElMessage } from 'element-plus'

const orders = ref([])

const PAY_METHOD_CHOICES = [
    '支付宝', '货到付款'
]

const STATUS_CHOICES = [
    '待支付',
    '待发货',
    '待收货',
    '待评价',
    '已完成',
    '已取消',
]
const TAG = [
    '', 'success', 'info', 'warning', 'danger'
]

getOrder().then(
    data => {
        orders.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)

function payment(order_id) {
    goPay(order_id).then(
        data => {
            window.location.href = data.pay_url
        },
        error => {
            ElMessage.error('订单提交失败')
            console.log('请求失败', error.message)
        }
    )
}

</script>

<style lang="less" scoped>
.el-header {
    display: flex;
    align-items: center;
}

.el-header h4 {
    color: #606266;
}

.info {
    display: flex;
    align-items: center;
}

.info h3 {
    color: #303133;
    font-size: 20px;
    letter-spacing: 5px;
}

.info h4 {
    color: #606266;
    font-size: 14px;
}

.count {
    color: #606266;
    margin-top: 30px;
}

.count_num {
    color: red;
    margin: 0 5px;
    font-size: 18px;
}

.tab_bottom {
    margin-top: 20px;
    display: flex;
    justify-content: right;
}

.gosettle {
    color: white;
    background-color: #f56c6c;
    padding: 20px 40px;
    font-size: 18px;
    cursor: pointer;
}

.total {
    text-align: right;
    padding: 10px;
    font-size: 12px;
}
</style>