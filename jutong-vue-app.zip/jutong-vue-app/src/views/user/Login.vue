<template>
    <div class="main">
        <div class="bg">
            <div class="slogan">
                <h2>欢迎登录</h2>
                <h2>Jutong</h2>
                <h2>知识聚集流通平台</h2>
            </div>
            <div class="form-box">
                <div class="main">
                    <h2>登录</h2>
                    <el-form :model="form" label-width="auto" :rules="rules" ref="ruleFormRef">
                        <el-form-item label="用户名" prop="username">
                            <el-input v-model="form.username"></el-input>
                        </el-form-item>
                        <el-form-item label="密码" prop="password">
                            <el-input v-model="form.password" type="password"></el-input>
                        </el-form-item>
                        <el-form-item label="验证码" prop="verify">
                            <el-input v-model="form.verify"></el-input>
                            <img class="verify" alt="请稍后重试" :src="verify_src" @click="get_verification_image" />
                        </el-form-item>
                        <el-form-item>
                            <el-button type="danger" class="sub-btn" @click="submitForm(ruleFormRef)">立即登录</el-button>
                        </el-form-item>
                    </el-form>
                    <div class="bottom-box">
                        <a href="/user/register/">暂无账号，立即注册</a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { login } from '@/api/user'
import { useRouter } from 'vue-router'
import { userStore } from '@/store/user'

const router = useRouter()

const user_store = userStore()

function generateUUID() {
    let d = new Date().getTime()
    let uuid = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        let r = (d + Math.random() * 16) % 16 | 0;
        d = Math.floor(d / 16);
        return (c == 'x' ? r : (r & 0x3 | 0x8)).toString(16)
    })
    return uuid;
}

let uuid = generateUUID()

const verify_src = ref(`/api/user/verification/login/${uuid}/`)

let verification_verification = setInterval(get_verification_image, 1000 * 60 * 3)

function get_verification_image() {
    clearInterval(verification_verification)

    verify_src.value = `/api/user/verification/login/${uuid}/?data=${new Date().getTime()}`

    verification_verification = setInterval(get_verification_image, 1000 * 60 * 1)
}

const ruleFormRef = ref()

// do not use same name with ref
const form = reactive({
    username: '',
    password: '',
    uuid: uuid,
    verify: ''
})

const rules = reactive({
    username: [
        {
            required: true,
            message: '请输入用户名',
            trigger: 'blur',
        }
    ],
    password: [
        {
            required: true,
            message: '请输入密码',
            trigger: 'blur',
        },
        {
            min: 6,
            message: '密码长度不能低于六位',
            trigger: 'blur',
        },
    ],
    verify: [
        {
            required: true,
            message: '请输入验证码',
            trigger: 'blur',
        },
        {
            min: 4,
            max: 4,
            message: '验证码长度为四位',
            trigger: 'blur',
        },
    ]
})

const submitForm = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            login(form).then((data) => {
                user_store.set_token(data.token)
                ElMessage({
                    message: '登录成功',
                    type: 'success',
                })
                router.push({
                    name: 'Home',
                })
            }).catch((error) => {
                let data = error.response.data
                for (let key in data) {
                    console.log(key);
                    ElMessage({
                        message: data[key][0],
                        type: 'warning',
                    })
                }
                get_verification_image()
            })
        } else {
            console.log('error submit!', fields)
        }
    })
}
</script>

<style lang="less" scoped>
.bg {
    width: 800px;
    height: 300px;
    background-color: #c45656;
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
    margin: auto;
    border-radius: 10px;
    box-shadow: rgba(100, 100, 111, 0.2) 0 7px 29px 0;
    display: flex;
    align-items: center;

    .slogan {
        color: white;
        width: 360px;
        text-align: center;

        h2 {
            margin: 20px;
            font-size: 26px;
        }
    }

    .form-box {
        width: 400px;
        height: 400px;
        background-color: white;
        box-shadow: rgba(0, 0, 0, 0.35) 0 5px 15px;
        border-radius: 10px;
        display: flex;
        align-items: center;
        color: #c45656;

        .main {
            margin: 40px;

            h2 {
                margin-bottom: 40px;
                text-align: center;
            }

            ul li {
                margin: 20px;
            }

            .verify {
                margin-top: 10px;
            }

            .sub-btn {
                width: 100%;
            }
        }
    }

    .bottom-box {
        text-align: right;
        font-size: 12px;
        text-decoration: underline;
    }

}
</style>