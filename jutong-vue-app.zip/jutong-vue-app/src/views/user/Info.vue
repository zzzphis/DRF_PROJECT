<template>
    <div v-loading.fullscreen.lock="!user">
        <el-form ref="ruleFormRef" :model="user" label-width="120px" class="demo-ruleForm" status-icon v-if="user">
            <el-form-item>
                <el-upload class="avatar-uploader" :action="updateAvatar().url" :method="updateAvatar().method"
                    :show-file-list="false" :on-success="handleAvatarSuccess" :before-upload="beforeAvatarUpload"
                    :headers="{
        'Authorization': 'Bearer ' + user_store.token
    }">
                    <img v-if="user.avatar" :src="'/file/' + user.avatar" class="avatar" fit="cover" />
                    <el-icon v-else class="avatar-uploader-icon">
                        <Plus />
                    </el-icon>
                </el-upload>
            </el-form-item>
            <el-form-item label="用户名" prop="name">
                <el-input v-model="user.username" disabled />
            </el-form-item>
            <el-form-item label="性别" prop="sex">
                <el-radio-group v-model="user.sex" @change="submitForm">
                    <el-radio :label="0">女</el-radio>
                    <el-radio :label="1">男</el-radio>
                </el-radio-group>
            </el-form-item>
            <el-form-item label="生日" prop="birthday">
                <el-date-picker v-model="user.birthday" value-format="YYYY-MM-DD" type="date" placeholder="请选择日期"
                    @change="submitForm" />
            </el-form-item>
            <el-form-item label="手机号码" prop="name">
                <el-input v-model="user.phone" @change="submitForm" />
            </el-form-item>
            <el-form-item>
                <el-button type="primary" round @click="dialogFormVisible = true">修改密码</el-button>
            </el-form-item>
        </el-form>
    </div>

    <el-dialog v-model="dialogFormVisible" title="修改密码">
        <el-form ref="ruleFormRef" :model="ruleForm" :rules="rules" label-width="120px" class="demo-ruleForm"
            status-icon>
            <el-form-item label="原密码" prop="password">
                <el-input v-model="ruleForm.password" type="password" />
            </el-form-item>
            <el-form-item label="新密码" prop="new_password">
                <el-input v-model="ruleForm.new_password" type="password" />
            </el-form-item>
            <el-form-item label="确认新密码" prop="re_new_password">
                <el-input v-model="ruleForm.re_new_password" type="password" />
            </el-form-item>
        </el-form>
        <template #footer>
            <span class="dialog-footer">
                <el-button @click="dialogFormVisible = false">取消</el-button>
                <el-button type="primary" @click="changePassword(ruleFormRef)">
                    提交
                </el-button>
            </span>
        </template>
    </el-dialog>
</template>

<script setup>
import { reactive, ref } from 'vue'
import { ElMessage } from 'element-plus'
import { useRouter } from 'vue-router'
import { Plus } from '@element-plus/icons-vue'

import { getUser, updateUser, updateUserPassword, updateAvatar } from '@/api/user'
import { userStore } from '@/store/user'

const user_store = userStore()
const router = useRouter()

const user = ref()
getUser().then((data) => {
    user.value = data
})

const imageUrl = ref('')

const handleAvatarSuccess = (
    response,
    uploadFile
) => {
    user.value.avatar = response.avatar
}

const beforeAvatarUpload = (rawFile) => {
    let type = rawFile.type
    if (type !== 'image/jpeg' && type !== 'image/png') {
        ElMessage.error('Avatar picture must be JPG or PNG format!')
        return false
    } else if (rawFile.size / 1024 / 1024 > 2) {
        ElMessage.error('Avatar picture size can not exceed 2MB!')
        return false
    }
    return true
}

const userInfoRef = ref()

const submitForm = async (formEl) => {
    updateUser(user.value).then((data) => {
        ElMessage({
            message: '修改成功',
            type: 'success',
        })
    }).catch((error) => {
        let data = error.response.data
        for (let key in data) {
            console.log(key);
            ElMessage({
                message: data[key][0],
                type: 'warning',
            })
        }
    })
}

const dialogFormVisible = ref(false)
const ruleFormRef = ref()
const ruleForm = reactive({
})
const rules = reactive({
    password: [
        { required: true, message: '请输入原密码', trigger: 'blur' },
        { min: 3, max: 20, message: '密码长度为3-20', trigger: 'blur' },
    ],
    new_password: [
        { required: true, message: '请输入新密码', trigger: 'blur' },
        { min: 3, max: 20, message: '密码长度为3-20', trigger: 'blur' },
    ],
    re_new_password: [
        { required: true, message: '请确认新密码', trigger: 'blur' },
        { min: 3, max: 20, message: '密码长度为3-20', trigger: 'blur' },
    ]
})

const changePassword = async (formEl) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            updateUserPassword(ruleForm).then((data) => {
                ElMessage({
                    message: '修改成功',
                    type: 'success',
                })
                user_store.del_token()
                router.push({
                    name: 'Login',
                })
            }).catch((error) => {
                let data = error.response.data
                for (let key in data) {
                    console.log(key);
                    ElMessage({
                        message: data[key][0],
                        type: 'warning',
                    })
                }
            })
        } else {
            console.log('error submit!', fields)
        }
    })
}

</script>

<style lang="less" scoped>
.avatar-uploader .avatar {
    width: 100px;
    height: 100px;
    display: block;
}
</style>

<style>
.avatar-uploader .el-upload {
    border: 1px dashed var(--el-border-color);
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
    transition: var(--el-transition-duration-fast);
}

.avatar-uploader .el-upload:hover {
    border-color: var(--el-color-primary);
}

.el-icon.avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 100px;
    height: 100px;
    text-align: center;
}
</style>