<template>
    <el-main v-if="commodity">
        <div class="tab">
            <p>{{ commodity.classification1_name }}</p>
            <span v-if="commodity.classification2_name">></span>
            <p>{{ commodity.classification2_name }}</p>
        </div>
        <div class="commodity">
            <div class="img">
                <!-- 放大镜效果 -->
                <enlarge-images :images="commodity.commodityimg_set" />
            </div>
            <div class="info">
                <h3 class="name">{{ commodity.name }}</h3>
                <h3 class="name">{{ commodity.caption }}</h3>
                <p>
                    <span class="info_title">品牌：</span>
                    {{ commodity.brand ? commodity.brand : '其他品牌' }}
                </p>
                <p>
                    <span class="info_title">PROMOTE价：</span>
                    <span style="color: red;font-size: 24px;">￥{{ commodity.price }}</span>
                </p>
                <el-divider></el-divider>
                <div>
                    <el-input-number v-model="form.number" :min="1" :max="commodity.stock" controls-position="right" />
                    <el-button @click="addcar" type="primary" style="margin:10px 20px">加入购物车</el-button>
                </div>
            </div>
        </div>
        <el-tabs v-model="activeName">
            <el-tab-pane label="规格与包装" name="first">包装清单：{{ commodity.pack ? commodity.pack : '暂无' }}</el-tab-pane>
            <el-tab-pane label="售后保障" name="second" v-html="commodity.serviceafter_sale"></el-tab-pane>
            <el-tab-pane :label="`商品评价(${commodity.comments})`" name="third"></el-tab-pane>
        </el-tabs>
    </el-main>
    <el-empty :image-size="200" v-else></el-empty>
</template>

<script setup>
import { ref } from 'vue'
import { getCommodityDetail, createCart } from '@/api/shopping'
import { useRoute } from "vue-router"
import { ElMessage } from 'element-plus'

const router = useRoute()
const commodity = ref()

const form = ref({
    number: 1,
    commodity: router.params.id
})

getCommodityDetail(router.params.id).then(
    data => {
        commodity.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)

function addcar() {
    createCart(form.value).then(
        data => {
            ElMessage.success('添加成功')
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
}

</script>

<style lang="less" scoped>
.tab {
    color: #666;
    font: 12px/150% tahoma, arial, Microsoft YaHei, Hiragino Sans GB,
        "\u5b8b\u4f53", sans-serif;
    display: flex;
    background-color: #f2f2f2;
    padding: 10px;
    margin-bottom: 20px;
}

.el-tabs .el-tab-pane {
    padding: 12px 0;
    line-height: 220%;
    color: #999;
    font-size: 12px;
}

.tab p {
    padding: 0px 20px;
}

.commodity {
    display: flex;
    margin-bottom: 50px;
}

.info {
    margin: 0px 50px;
}

.info .name {
    font: 700 18px Arial, "microsoft yahei";
    color: #666;
    margin-bottom: 20px;
}

.info p {
    margin-top: 20px;
    color: #666;
}

.info .info_title {
    color: gray;
    letter-spacing: 3px;
}
</style>