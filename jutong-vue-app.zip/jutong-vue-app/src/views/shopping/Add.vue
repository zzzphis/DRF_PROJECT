<template>
    <el-form :model="form" class="demo-ruleForm" label-position="right" label-width="100px" :rules="rules" ref="formEl">
        <el-form-item label="商品名" prop="name">
            <el-input v-model="form.name"></el-input>
        </el-form-item>
        <el-form-item label="副标题" prop="caption">
            <el-input v-model="form.caption"></el-input>
        </el-form-item>
        <el-form-item label="品牌" prop="brand">
            <el-input v-model="form.brand"></el-input>
        </el-form-item>
        <el-form-item label="单价" prop="price">
            <el-input-number v-model="form.price" :precision="1" :step="1" :max="100000" controls-position="right" />
        </el-form-item>
        <el-form-item label="库存" prop="stock">
            <el-input-number v-model="form.stock" :precision="1" :step="1" :max="100000" controls-position="right" />
        </el-form-item>
        <el-form-item label="选择类目" prop="district">
            <el-select v-model="form.classification1" placeholder="请选择一级类目">
                <el-option :label="classification.name" :value="classification.id" :key="classification.id"
                    v-for="classification in classifications"></el-option>
            </el-select>-
            <el-select v-model="form.classification2" placeholder="请选择二级类目">
                <el-option :label="classification.name" :value="classification.id" :key="classification.id"
                    v-for="classification in classifications2"></el-option>
            </el-select>
        </el-form-item>
        <el-form-item label="商品图">
            <el-upload ref="uploadRef" action="" method="" list-type="picture-card" :on-preview="handlePictureCardPreview"
                :headers="{
                    'Authorization': 'JWT ' + user_store.token
                }" :auto-upload="false" :data="form" multiple v-model:file-list="fileList">
                <el-icon>
                    <Plus />
                </el-icon>
            </el-upload>
            <el-dialog v-model="dialogVisible">
                <img width="100%" :src="dialogImageUrl" alt />
            </el-dialog>
        </el-form-item>
        <el-form-item label="包装信息" prop="pack">
            <el-input v-model="form.pack"></el-input>
        </el-form-item>
        <el-form-item label="售后服务" prop="serviceafter_sale">
            <el-input v-model="form.serviceafter_sale" type="textarea" :rows="3"></el-input>
        </el-form-item>
        <el-form-item>
            <el-button type="primary" @click="submitForm(formEl, 1)">立即上架</el-button>
            <el-button type="primary" @click="submitForm(formEl, 0)">保存商品</el-button>
        </el-form-item>
    </el-form>
</template>

<script setup>
import { ref, watch } from 'vue'
import { Plus } from '@element-plus/icons-vue'
import { getClassifications, creatCommodity } from '@/api/shopping'
import { userStore } from '@/store/user'
import { ElMessage } from 'element-plus'

const user_store = userStore()
const formEl = ref()
const form = ref({
    name: '',
    caption: '',
    price: 0.0,
    stock: 0.0,
    brand: '',
    detail: '',
    pack: '',
    serviceafter_sale: '',
    status: 0,
    classification1: '',
    classification2: '',
})

const fileList = ref([
])

const rules = ref({
    name: [
        {
            required: true,
            message: '请输入商品名',
            trigger: 'blur',
        },
        {
            min: 1,
            max: 40,
            message: '长度为1-40',
            trigger: 'blur',
        },
    ],
    caption: [
        {
            required: true,
            message: '请输入商品副标题',
            trigger: 'blur',
        },
        {
            min: 1,
            max: 140,
            message: '长度为1-140',
            trigger: 'blur',
        },
    ],

    classification1: [
        {
            required: true,
            message: '请选择类目',
            trigger: 'change',
        },
    ]
})
const classifications = ref({
})
const classifications2 = ref([
])

getClassifications().then(
    data => {
        classifications.value = {}
        data.forEach(e => {
            classifications.value[e.id] = e
        });
    },
    error => {
        console.log('请求失败', error.message)
    }
)

watch(() => form.value.classification1, (value, prevValue) => {
    classifications2.value = classifications.value[value].classification_set
    form.value.classification2 = ''
})

const dialogImageUrl = ref()
const dialogVisible = ref()
function handlePictureCardPreview(file) {
    dialogImageUrl.value = file.url
    dialogVisible.value = true
}
const uploadRef = ref()

const submitForm = async (formEl, status) => {
    if (!formEl) return
    await formEl.validate((valid, fields) => {
        if (valid) {
            form.value.status = status
            var data = new FormData()
            for (let i = 0; i < fileList.value.length; i++) {
                data.append('file', fileList.value[i].raw)
            }
            for (let key in form.value) {
                data.append(key, form.value[key]);
            }
            // uploadRef.value.submit()
            creatCommodity(data).then((data) => {
                ElMessage({
                    message: '添加成功',
                    type: 'success',
                })
            })
        } else {
            console.log('error submit!!')
            return false
        }
    })
}
</script>

<style lang="less" scoped></style>