<template>
    <el-card class="box-card">
        <template #header>
            <div class="card-header">
                <span>确认收货地址</span>
            </div>
        </template>
        <div v-if="address.length > 0">
            <p style="font-weight: bolder;">寄送到</p>
            <div v-for="res in address" :key="res.id" class="text item">
                <el-radio v-model="form.address" :label="res.id">{{ res.province_name }} {{ res.city_name }} {{
                    res.district_name }} {{ res.place }} 【{{ res.receiver }} 收】 {{ res.mobile }}</el-radio>
            </div>
        </div>
        <el-empty :image-size="200" v-else></el-empty>
    </el-card>
    <el-card class="box-card">
        <template #header>
            <div class="card-header">
                <span>支付方式</span>
            </div>
        </template>
        <div class="text item">
            <el-radio v-model="form.pay_method" label="1">支付宝</el-radio>
            <el-radio v-model="form.pay_method" label="2">货到付款</el-radio>
        </div>
    </el-card>
    <el-card class="box-card">
        <template #header>
            <div class="card-header">
                <span>商品列表</span>
            </div>
        </template>
        <div v-if="carts.length > 0">
            <el-table :data="carts" style="width: 100%" stripe>
                <el-table-column label width="150">
                    <template #default="scope">
                        <img :src="'/file/' + scope.row.commodityDetail.commodityimg_set[0].src" fit="contain"
                            width="120" />
                    </template>
                </el-table-column>
                <el-table-column property="commodityDetail.name" label="商品名称" />
                <el-table-column label="商品价格">
                    <template #default="scope">{{ scope.row.commodityDetail.price }}元</template>
                </el-table-column>
                <el-table-column label="数量" property="number"></el-table-column>
                <el-table-column label="小计">
                    <template #default="scope">{{ scope.row.commodityDetail.price * scope.row.number }}元</template>
                </el-table-column>
            </el-table>
        </div>
    </el-card>
    <el-card class="box-card">
        <template #header>
            <div class="card-header">
                <span>总金额结算</span>
            </div>
        </template>
        <div class="text item tab_bottom">
            <div class="total">
                <p>
                    共
                    <span class="count_num">{{ count }}</span>件商品
                    总金额：
                    <span class="count_num">{{ money }}元</span>
                </p>
                <p>
                    实付款
                    <span class="count_num">{{ money }}元</span>
                </p>
            </div>
        </div>
    </el-card>
    <div class="tab_bottom">
        <div class="gosettle" @click="addOrder">提交订单</div>
    </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { getCartDetail, createOrder } from '@/api/shopping'
import { getAddress } from '@/api/user'
import { useRoute } from "vue-router"
import { ElMessage } from 'element-plus'

const address = ref([])
getAddress().then((data) => {
    address.value = data
})

const carts = ref([])
const route = useRoute()
route.query.selectcommodityid.forEach(e => {
    getCartDetail(e).then(
        data => {
            carts.value.push(data)
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
})

const form = ref({
    address: null,
    pay_method: "1",
    cart: route.query.selectcommodityid
})

function addOrder() {
    if (!form.value.address) {
        ElMessage.error('请选择收货地址')
        return false
    }
    if (!form.value.pay_method) {
        ElMessage.error('请选择支付方式')
        return false
    }
    createOrder(form.value).then(
        data => {
            ElMessage.success('操作成功')
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
}

const count = computed(() => {
    let count = 0
    carts.value.forEach(e => {
        count += e.number
    })
    return count
})
const money = computed(() => {
    let maney = 0
    carts.value.forEach(e => {
        maney += e.number * e.commodityDetail.price
    })
    return maney
})
</script>

<style lang="less" scoped>
.box-card {
    margin: 20px 0px;
}

.card-header {
    color: #606266;
}

.item {
    margin: 10px 0px;
}

.count_num {
    color: red;
    margin: 0 5px;
    font-size: 18px;
}

.tab_bottom {
    margin-top: 20px;
    display: flex;
    justify-content: right;
}

.gosettle {
    color: white;
    background-color: #f56c6c;
    padding: 20px 40px;
    font-size: 18px;
    cursor: pointer;
}

.total {
    text-align: right;
    padding: 10px;
    font-size: 12px;
}
</style>