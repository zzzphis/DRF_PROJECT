<template>
    <div class="header">
        <el-menu default-active="2" class="el-menu-vertical-demo" :collapse="true" router v-if="classifications.length > 0">
            <el-sub-menu :index="String(index)" v-for="(classification, index) in classifications" :key="classification.id">
                <template #title>
                    <router-link :to="'/shopping/' + classification.id">{{ classification.name }}</router-link>
                </template>
                <el-menu-item-group>
                    <template #title>
                        <span>{{ classification.name }}</span>
                    </template>
                    <el-menu-item :index="'/shopping/' + classificationsub.id"
                        v-for="(classificationsub, index) in classification.classification_set"
                        :key="classificationsub.id">{{ classificationsub.name }}</el-menu-item>
                </el-menu-item-group>
            </el-sub-menu>
        </el-menu>
        <el-carousel :interval="4000" type="card" height="400px" arrow="never">
            <el-carousel-item v-for="banner in banners" :key="banner.id">
                <img :src="banner.src" style="width: 100%;" />
            </el-carousel-item>
        </el-carousel>
    </div>

    <div class="box">
        <h3 class="title">优选</h3>
        <el-row :gutter="10" justify="space-around" v-if="optimizations.length > 0">
            <el-col v-for="(optimization, index) in optimizations" :key="optimization.id" :span="4">
                <router-link :to="'/shopping/commodity/' + optimization.id">
                    <el-card :body-style="{ padding: '0px' }" shadow="hover">
                        <img :src="'/file/' + optimization.commodityimg_set[0]['src']" class="image" />
                        <div class="product">
                            <p class="price">￥{{ optimization.price }}</p>
                            <h4 class="name">{{ optimization.name }}{{ optimization.caption }}</h4>
                            <p>
                                {{ optimization.comments }}
                                <span style="color: gray;">条评价</span>
                            </p>
                            <p style="color: gray;">{{ optimization.brand ? optimization.brand : '其他品牌' }}</p>
                            <div class="bottom">
                                <el-button type="text" class="button" @click="addcar(optimization.id)">加入购物车</el-button>
                            </div>
                        </div>
                    </el-card>
                </router-link>
            </el-col>
        </el-row>
        <el-empty :image-size="200" v-else></el-empty>
    </div>

    <div class="box">
        <h3 class="title">畅销</h3>
        <el-row :gutter="10" justify="space-around" v-if="optimizations.length > 0">
            <el-col v-for="(optimization, index) in optimizations" :key="optimization.id" :span="4">
                <router-link :to="'/shopping/commodity/' + optimization.id">
                    <el-card :body-style="{ padding: '0px' }" shadow="hover">
                        <img :src="'/file/' + optimization.commodityimg_set[0]['src']" class="image" />
                        <div class="product">
                            <p class="price">￥{{ optimization.price }}</p>
                            <h4 class="name">{{ optimization.name }}{{ optimization.caption }}</h4>
                            <p>
                                {{ optimization.comments }}
                                <span style="color: gray;">条评价</span>
                            </p>
                            <p style="color: gray;">{{ optimization.brand ? optimization.brand : '其他品牌' }}</p>
                            <div class="bottom">
                                <el-button type="text" class="button" @click="addcar(optimization.id)">加入购物车</el-button>
                            </div>
                        </div>
                    </el-card>
                </router-link>
            </el-col>
        </el-row>
        <el-empty :image-size="200" v-else></el-empty>
    </div>
</template>

<script setup>
import { ref } from 'vue'
import { getClassifications, getOptimization, createCart } from '@/api/shopping'
import imgUrl1 from '../../assets/imgs/banner1.webp'
import imgUrl2 from '../../assets/imgs/banner2.webp'
import imgUrl3 from '../../assets/imgs/banner3.webp'
import { ElNotification } from 'element-plus'

const banners = ref([
    {
        'id': 1,
        'src': imgUrl1
    },
    {
        'id': 2,
        'src': imgUrl2
    },
    {
        'id': 3,
        'src': imgUrl3
    }
])

const classifications = ref([])

getClassifications().then(
    data => {
        classifications.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)

const optimizations = ref([])
getOptimization().then(
    data => {
        optimizations.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)

function addcar(commodity) {
    createCart({
        number: 1,
        commodity: commodity
    }).then(
        data => {
            ElNotification({
                title: 'Success',
                message: '添加成功',
                type: 'success',
            })
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
}
</script>

<style lang="less" scoped>
.header {
    position: relative;
    height: 400px;
}

.el-carousel__item {
    display: flex;
    align-items: center;
    background-color: white;
}

.el-menu--collapse {
    width: 200px;
    font-weight: normal;
    overflow: hidden;
    text-overflow: ellipsis;
}

.el-menu--collapse a {
    font-weight: normal;
    overflow: hidden;
    text-overflow: ellipsis;
}

.el-menu-vertical-demo {
    position: absolute;
    z-index: 99;
    height: 100%;
}

.el-carousel__item h3 {
    color: #475669;
    font-size: 14px;
    opacity: 0.75;
    line-height: 200px;
    margin: 0;
    text-align: center;
}

.box .title {
    margin: 30px 0px;
    font-size: 28px;
    color: #483d8b;
}

.image {
    width: 100%;
}

.price {
    color: red;
    font-size: 18px;
    font-weight: bold;
}

.name {
    white-space: nowrap;
    font-size: 16px;
    font-weight: normal;
    overflow: hidden;
    text-overflow: ellipsis;
}

.product {
    padding: 14px;
    font-size: 12px;
}

.product p {
    margin: 5px 0px;
}
</style>