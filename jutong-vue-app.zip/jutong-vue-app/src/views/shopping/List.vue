<template>
    <div class="box" v-if="commoditys.commodity.length > 0">
        <h3 class="title">{{ commoditys.classification }}</h3>
        <el-row :gutter="10">
            <el-col v-for="(commodity, index) in commoditys.commodity" :key="commodity.id" :span="4">
                <router-link :to="'/shopping/commodity/' + commodity.id">
                    <el-card :body-style="{ padding: '0px' }" shadow="hover">
                        <img :src="'/file/' + commodity.commodityimg_set[0]['src']" class="image" />
                        <div class="product">
                            <p class="price">￥{{ commodity.price }}</p>
                            <h4 class="name">{{ commodity.name }}{{ commodity.caption }}</h4>
                            <p>
                                {{ commodity.comments }}
                                <span style="color: gray;">条评价</span>
                            </p>
                            <p style="color: gray;">{{ commodity.brand ? commodity.brand : '其他品牌' }}</p>
                            <div class="bottom">
                                <el-button type="text" class="button">加入购物车</el-button>
                            </div>
                        </div>
                    </el-card>
                </router-link>
            </el-col>
        </el-row>
    </div>
    <el-empty :image-size="200" v-else></el-empty>
</template>

<script setup>
import { ref } from 'vue'
import { getClassificationsCommodity } from '@/api/shopping'
import { useRoute } from "vue-router"

const commoditys = ref({
    commodity: []
})
const router = useRoute()
getClassificationsCommodity(router.params.id).then(
    data => {
        commoditys.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)
</script>

<style lang="less" scoped>
.header {
    position: relative;
}

.box .title {
    margin: 30px 0px;
    font-size: 28px;
    color: #483d8b;
}

.image {
    width: 100%;
}

.price {
    color: red;
    font-size: 18px;
    font-weight: bold;
}

.name {
    white-space: nowrap;
    font-size: 16px;
    font-weight: normal;
    overflow: hidden;
    text-overflow: ellipsis;
}

.product {
    padding: 14px;
    font-size: 12px;
}

.product p {
    margin: 5px 0px;
}

.el-card {
    margin-bottom: 20px;
}
</style>