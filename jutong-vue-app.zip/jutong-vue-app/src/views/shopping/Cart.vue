<template>
    <el-header>
        <div class="info">
            <!-- <img src="../../assets/imgs/logo_i.png" height="60" /> -->
            <div>
                <h3>Jutong</h3>
                <h4>Jutong系统</h4>
            </div>
        </div>
        <el-divider direction="vertical"></el-divider>
        <h4>购物车</h4>
    </el-header>
    <div class="count">
        全部商品
        <span class="count_num">{{ count }}</span>件
    </div>
    <el-table ref="multipleTable" :data="cart" style="width: 100%" @selection-change="handleSelectionChange" stripe>
        <el-table-column type="selection" width="55" />
        <el-table-column label width="150">
            <template #default="scope">
                <img :src="'/file/' + scope.row.commodityDetail.commodityimg_set[0].src" fit="contain" width="120" />
            </template>
        </el-table-column>
        <el-table-column property="commodityDetail.name" label="商品名称" />
        <el-table-column label="商品价格">
            <template #default="scope">{{ scope.row.commodityDetail.price }}元</template>
        </el-table-column>
        <el-table-column label="数量">
            <template #default="scope">
                <el-input-number v-model="scope.row.number" :min="1" :max="scope.row.commodityDetail.stock"
                    controls-position="right"
                    @change="cartChange(scope.row.id, scope.row.number, scope.row.commodityDetail.id)" />
            </template>
        </el-table-column>
        <el-table-column label="小计">
            <template #default="scope">{{ scope.row.commodityDetail.price * scope.row.number }}元</template>
        </el-table-column>
        <el-table-column label="操作" show-overflow-tooltip>
            <template #default="scope">
                <el-popconfirm confirm-button-text="确定" cancel-button-text="再考虑考虑" icon-color="red" title="你确定要从购物车中移除该商品吗？"
                    @confirm="handleDelete(scope.$index, scope.row)">
                    <template #reference>
                        <el-button type="danger">删除</el-button>
                    </template>
                </el-popconfirm>
            </template>
        </el-table-column>
    </el-table>
    <div class="tab_bottom">
        <div class="total">
            <p>
                合计（不含运费）：
                <span class="count_num">￥{{ selectManey }}</span>
            </p>
            <p>
                共计
                <span class="count_num">{{ selectCount }}</span>件商品
            </p>
        </div>
        <div class="gosettle" @click="gosettle">去结算</div>
    </div>
</template>

<script setup>
import { ref, computed } from 'vue'
import { getCart, delCart, changeCart } from '@/api/shopping'
import { useRouter } from "vue-router"

const router = useRouter()

const cart = ref([])

getCart().then(
    data => {
        cart.value = data
    },
    error => {
        console.log('请求失败', error.message)
    }
)

function handleDelete(index, row) {
    delCart(row.id).then(
        data => {
            cart.value.splice(index, 1)
            console.log('请求成功', data)
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
}

function cartChange(id, number, commodity) {
    changeCart(id, { number: number, commodity: commodity }).then(
        data => {
            console.log('请求成功', data)
        },
        error => {
            console.log('请求失败', error.message)
        }
    )
}

const selectcommodity = ref([])

const count = computed(() => {
    let count = 0
    cart.value.forEach(e => {
        count += e.number
    })
    return count
})

const selectCount = computed(() => {
    let count = 0
    selectcommodity.value.forEach(e => {
        count += e.number
    })
    return count
})

const selectManey = computed(() => {
    let maney = 0
    selectcommodity.value.forEach(e => {
        maney += e.number * e.commodityDetail.price
    })
    return maney
})

function handleSelectionChange(val) {
    let commodity = {}
    cart.value.forEach(e => {
        commodity[e.id] = e
    })
    let data = []
    val.forEach(e => {
        data.push(commodity[e.id])
    })
    selectcommodity.value = data
}

function gosettle() {
    let selectcommodityid = []
    selectcommodity.value.forEach(e => {
        selectcommodityid.push(e.id)
    })
    router.push({ name: 'Settle', query: { selectcommodityid: selectcommodityid } })
}
</script>

<style lang="less" scoped>
.el-header {
    display: flex;
    align-items: center;
}

.el-header h4 {
    color: #606266;
}

.info {
    display: flex;
    align-items: center;
}

.info h3 {
    color: #303133;
    font-size: 20px;
    letter-spacing: 5px;
}

.info h4 {
    color: #606266;
    font-size: 14px;
}

.count {
    color: #606266;
    margin-top: 30px;
}

.count_num {
    color: red;
    margin: 0 5px;
    font-size: 18px;
}

.tab_bottom {
    margin-top: 20px;
    display: flex;
    justify-content: right;
}

.gosettle {
    color: white;
    background-color: #f56c6c;
    padding: 20px 40px;
    font-size: 18px;
    cursor: pointer;
}

.total {
    text-align: right;
    padding: 10px;
    font-size: 12px;
}
</style>