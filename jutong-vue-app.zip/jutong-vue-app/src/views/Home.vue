<template>
    <div v-loading.fullscreen.lock="!user">
        <el-menu :default-active="activeIndex" class="el-menu-demo" mode="horizontal" :ellipsis="false" router>
            <el-menu-item index="/">Jutong</el-menu-item>
            <div class="flex-grow" />
            <el-menu-item index="/article">论坛</el-menu-item>
            <el-menu-item index="/shopping">商城</el-menu-item>
            <el-sub-menu index="3" v-if="user">
                <template #title>
                    <el-avatar v-if="user.avatar" :size="30" :src="'/file/' + user.avatar" />
                    {{ user.username }}
                </template>
                <el-menu-item index="/shopping/add">商品添加</el-menu-item>
                <el-menu-item index="/user">个人信息</el-menu-item>
                <el-menu-item index="/user/address">收货地址</el-menu-item>
                <el-menu-item index="/user/cart">购物车</el-menu-item>
                <el-menu-item index="/user/order">个人订单</el-menu-item>
                <el-menu-item @click="exit">退出登录</el-menu-item>
            </el-sub-menu>
        </el-menu>
        <div class="content">
            <router-view></router-view>
        </div>
    </div>
</template>

<script setup>
import { ref } from 'vue'

import { getUser } from '@/api/user'
import { useRouter } from 'vue-router'
import { userStore } from '@/store/user'

const router = useRouter()
const user_store = userStore()

const user = ref()
getUser().then((data) => {
    user.value = data
}).catch((error) => {
    router.push({
        name: 'Login',
    })
})

function exit() {
    user_store.del_token()
    router.push({
        name: 'Login',
    })
}

const activeIndex = ref('/article')
</script>

<style lang="less" scoped>
.flex-grow {
    flex-grow: 1;
}

.content {
    padding: 20px;
}

.el-avatar {
    margin-right: 10px;
}
</style>