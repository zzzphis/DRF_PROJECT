<template>
    <div>
        <el-card shadow="hover" @click="router.push({
            name: 'Topic',
        })"> 题库 </el-card>
        <el-card shadow="hover" @click="router.push({
            name: 'Article',
        })"> 社区 </el-card>
        <el-card shadow="hover" @click="router.push({
            name: 'Shopping',
        })"> 商城 </el-card>
    </div>
</template>

<script setup>
import { useRouter } from 'vue-router'

const router = useRouter()
</script>

<style lang="less" scoped>
.el-card{
    margin: 20px 0px;
}
</style>