import {
    defineStore
} from 'pinia'
import {
    ref
} from 'vue'


export const userStore = defineStore('user_store', () => {
    // 用户信息
    const token = ref()

    async function set_token(data) {
        token.value = data
        return data
    }

    function del_token() {
        token.value = null
    }

    return {
        token,
        set_token,
        del_token
    }
}, {
    persist: {
        paths: ['token'],
    }
})