import EnlargeImages from './enlarge-images.vue'

export default {
    install(app) {
        app.component(EnlargeImages.name, EnlargeImages)
    }
}