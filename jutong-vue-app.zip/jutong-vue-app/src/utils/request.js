import Aixos from 'axios'
// 引入进度条
import nProgress from 'nprogress';
import "nprogress/nprogress.css"

import {
    ElMessage
} from 'element-plus'

import { userStore } from '@/store/user'

const axios = Aixos.create({
    // 基础路径，请求地址前会加上
    baseURL: '/api',
    // headers: {
    //     'Content-Type': 'application/json',
    //     // 'Authorization': `JWT ${localStorage.getItem('Authorization')}`
    // },
    // 请求超时时间 5s
    timeout: 5000,
})

// 添加请求拦截器
axios.interceptors.request.use(function (config) {
    // 在发送请求之前做些什么，config-配置对象
    // 进度条开始
    const user_store = userStore()
    if (user_store.token){
        config.headers.Authorization = 'Bearer ' + user_store.token
    }
    
    nProgress.start()
    return config;
}, function (error) {
    // 对请求错误做些什么
    return Promise.reject(error);
});

// 添加响应拦截器
axios.interceptors.response.use(function (response) {
    // 2xx 范围内的状态码都会触发该函数。
    // 对响应数据做点什么
    // 进度条结束
    nProgress.done()
    return response.data;
}, function (error) {
    // 超出 2xx 范围的状态码都会触发该函数。
    // 对响应错误做点什么
    switch (error.response.status) {
        case 500:
            ElMessage.error('服务器异常，请稍后重试')
            break;
        case 401:
            ElMessage({
                message: '登陆失效，请重新登陆',
                type: 'warning',
            })
            break;
        default:
            break;
    }
    nProgress.done()
    return Promise.reject(error);
});

export default axios