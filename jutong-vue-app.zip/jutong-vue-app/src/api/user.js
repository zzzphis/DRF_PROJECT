import request from '@/utils/request'

// 注册
export const register = (data) => request({
    url: '/user/users/',
    method: 'POST',
    data
})

// 登录
export const login = (data) => request({
    url: '/user/login/',
    method: 'POST',
    data
})

// 获取用户信息
export const getUser = () => request({
    url: '/user/users/now/',
    method: 'GET',
})

// 修改用户头像
export const updateAvatar = () => {
    return {
        url: `/api/user/users/info/`,
        method: 'put',
    }
}

// 修改用户信息
export const updateUser = (data) => request({
    url: `/user/users/info/`,
    method: 'PUT',
    data
})

// 修改用户密码
export const updateUserPassword = (data) => request({
    url: `/user/users/password/`,
    method: 'PUT',
    data
})

// 获取行政区划
export const getArea = () => request({
    url: '/user/area/',
    method: 'GET',
})
export const getAreaDetail = (id) => request({
    url: `/user/area/${id}/`,
    method: 'GET',
})

// 添加收货地址
export const addAddress = (data) => request({
    url: '/user/address/',
    method: 'POST',
    data
})

// 删除收货地址
export const delAddress = (id) => request({
    url: `/user/address/${id}/`,
    method: 'DELETE'
})

// 获取收货地址
export const getAddress = () => request({
    url: '/user/address/',
    method: 'GET',
})