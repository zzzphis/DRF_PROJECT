import request from '@/utils/request'

// 题目搜索
export const topicsSearch = (params) => request({
    url: '/work/topic/search/',
    method: 'GET',
    params
})