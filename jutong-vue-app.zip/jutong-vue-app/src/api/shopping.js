import request from '@/utils/request'

// 获取商品分类信息
export const getClassifications = () => request({
    url: '/shopping/classifications/',
    method: 'GET',
})

// 商品上传
export const creatCommodity = (data) => request({
    url: `/shopping/commoditys/`,
    method: 'post',
    data
})

// 获取优选
export const getOptimization = () => request({
    url: '/shopping/commoditys/optimization/',
    method: 'GET',
})

// 获取优选
export const getClassificationsCommodity = (id) => request({
    url: `/shopping/classifications/${id}/commodity/`,
    method: 'GET',
})

// 获取商品详情
export const getCommodityDetail = (id) => request({
    url: `/shopping/commoditys/${id}/`,
    method: 'get'
})

// 获取商品详情
export const createCart = (data) => request({
    url: `/shopping/cart/`,
    method: 'post',
    data
})

// 获取购物车
export const getCart = () => request({
    url: '/shopping/cart/',
    method: 'GET',
})

// 删除购物车商品
export const delCart = (id) => request({
    url: `/shopping/cart/${id}/`,
    method: 'delete',
})

// 修改购物车商品
export const changeCart = (id, data) => request({
    url: `/shopping/cart/${id}/`,
    method: 'put',
    data
})

// 获取购物车详情
export const getCartDetail = (id) => request({
    url: `/shopping/cart/${id}/`,
    method: 'GET',
})

// 创建订单
export const createOrder = (data) => request({
    url: `/shopping/order/`,
    method: 'post',
    data
})

// 获取订单
export const getOrder = () => request({
    url: '/shopping/order/',
    method: 'GET',
})

// 订单支付
export const goPay = (id) => request({
    url: `/shopping/payments/${id}/pay/`,
    method: 'GET',
})

// 修改订单状态
export const changeOrder = (param) => request({
    url: `/shopping/order/status/${param}/`,
    method: 'put'
})