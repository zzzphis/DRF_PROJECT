import request from '@/utils/request'

// 社区
export const getArticle = (params) => request({
    url: '/community/articles/',
    method: 'GET',
    params
})

// 标签
export const getLabel = () => request({
    url: '/community/labels/',
    method: 'GET'
})

export const createArticle = (data) => request({
    url: '/community/articles/',
    method: 'POST',
    data
})

// 获取商品详情
export const getArticleDetail = (id) => request({
    url: `/community/articles/${id}/`,
    method: 'get'
})